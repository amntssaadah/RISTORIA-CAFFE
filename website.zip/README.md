# php-mysql
Contoh program PHP dan database MySQL. Video lengkap setiap contoh dapat di akses di https://studio.youtube.com/channel/UCEkxEaqpzZQJb3NDwc4B-ew

Untuk dapat menjalankan semua contoh, silakan install web server apache dan MySQL, dapat menggunakan paket instalasi XAMPP atau WAMMP.
